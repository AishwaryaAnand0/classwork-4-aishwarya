/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<conio.h>
union MyUnion
{
    int num1;
    float num2;
};
int main()
{
    union MyUnion UN;
    printf("\n Size of union : %d", sizeof(UN));
    UN.num1=30;
    printf("\n Num1:%d, \n Num2: %f",UN.num1,UN.num2);
    UN.num2=30.34f;
    printf("\n Num1:%d,\n Num2:%f",UN.num1,UN.num2);
    return 0;
}



