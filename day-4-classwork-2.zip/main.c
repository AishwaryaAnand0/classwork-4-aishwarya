/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<conio.h>
struct manager
{
    char name[50];
    int manId ;
    int age ;
    float salary ;
};
int main()
{
    struct manager man;
    printf("\n Enter manager details !\n") ;
    printf("\n Name : ") ;
    scanf("%s",man.name ) ;
    printf("\n ID : ") ;
    scanf("%d",&man.manId ) ;
    printf("\n Age : ") ;
    scanf("%d",&man.age ) ;
    printf("\n Salary : ") ;
    scanf("%f",&man.salary ) ;
    printf("\n Entered manager detail are !" ) ;
    printf("\n Name: %s" ,man.name ) ;
    printf("\n Id: %d" ,man.manId ) ;
    printf("\n age: %d" ,man.age ) ;
    printf("\n Salary: %f\n",man.salary ) ;
    return 0 ;
}

