/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<string.h>
union Data 
{
    int i;
    float a;
    char str[20];
};
int main()
{
    union Data data;
    data.i=10;
    data.a=220.5;
    strcpy(data.str,"c programming");
    printf("data.i:%d\n",data.i);
    printf("data.a:%f\n",data.a);
    printf("data.str:%s\n",data.str);
    return 0;
}
